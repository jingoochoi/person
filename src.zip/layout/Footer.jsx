export function Footer() {
    return(
        <></>
    )
}