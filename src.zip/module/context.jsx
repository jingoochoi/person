import { createContext } from "react";

export const ctxt=createContext()